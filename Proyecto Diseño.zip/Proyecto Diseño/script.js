let taskTable = document.getElementById("taskTable");
let taskInput = document.getElementById("task");
let dateInput = document.getElementById("date");
let timeInput = document.getElementById("time");

function addTask() {
	let task = taskInput.value;
	let date = dateInput.value;
	let time = timeInput.value;

	if (task === "" || date === "" || time === "") {
		alert("Por favor, completa todos los campos.");
		return;
	}

	let newRow = taskTable.insertRow();
	let taskCell = newRow.insertCell();
	let dateCell = newRow.insertCell();
	let timeCell = newRow.insertCell();
	let deleteCell = newRow.insertCell();

	taskCell.innerHTML = task;
	dateCell.innerHTML = date;
	timeCell.innerHTML = time;
	deleteCell.innerHTML = '<button onclick="deleteTask(this)">Eliminar</button>';
}

function deleteTask(button) {
	let row = button.parentNode.parentNode;
	row.parentNode.removeChild(row);
}